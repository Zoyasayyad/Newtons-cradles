# NC27
Output link: https://chetan-whjr.github.io/Newton-s-cradles/
